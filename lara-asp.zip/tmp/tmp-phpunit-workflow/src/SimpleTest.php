<?php declare(strict_types = 1);

class SimpleTest extends \PHPUnit\Framework\TestCase  {
    public function testSimple() {
        $this->assertTrue(true);
    }
}
