<?php declare(strict_types = 1);

namespace Test;

use function str_pad;

use const STR_PAD_RIGHT;

echo str_pad('123', 1, pad_type: STR_PAD_RIGHT);
