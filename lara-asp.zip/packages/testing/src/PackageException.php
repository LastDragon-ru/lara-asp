<?php declare(strict_types = 1);

namespace LastDragon_ru\LaraASP\Testing;

use Throwable;

interface PackageException extends Throwable {
    // empty
}
