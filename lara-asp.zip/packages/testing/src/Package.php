<?php declare(strict_types = 1);

namespace LastDragon_ru\LaraASP\Testing;

final class Package {
    public const Name = 'lara-asp-testing';
}
