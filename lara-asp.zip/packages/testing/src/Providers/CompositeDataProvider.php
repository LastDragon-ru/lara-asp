<?php declare(strict_types = 1);

namespace LastDragon_ru\LaraASP\Testing\Providers;

use function array_merge;
use function array_reduce;
use function array_reverse;
use function array_slice;
use function reset;

/**
 * The data provider allows merging several data providers into one. It works in
 * the following way:
 *
 *      Initial:
 *      [
 *          ['expected a', 'value a'],
 *          ['expected final', 'value final'],
 *      ]
 *      [
 *          ['expected b', 'value b'],
 *          ['expected c', 'value c'],
 *      ]
 *      [
 *          ['expected d', 'value d'],
 *          ['expected e', 'value e'],
 *      ]
 *
 *      Merged:
 *      [
 *          '0 / 0 / 0' => ['expected d', 'value a', 'value b', 'value d'],
 *          '0 / 0 / 1' => ['expected e', 'value a', 'value b', 'value e'],
 *          '0 / 1 / 0' => ['expected d', 'value a', 'value c', 'value d'],
 *          '0 / 1 / 1' => ['expected e', 'value a', 'value c', 'value e'],
 *          '1'         => ['expected final', 'value final'],
 *      ]
 */
class CompositeDataProvider implements DataProvider {
    /**
     * @var array<\LastDragon_ru\LaraASP\Testing\Providers\DataProvider>
     */
    private array $providers;

    public function __construct(DataProvider ...$providers) {
        $this->providers = $providers;
    }

    // <editor-fold desc="Getters / Setters">
    // =========================================================================
    /**
     * @return array<\LastDragon_ru\LaraASP\Testing\Providers\DataProvider>
     */
    protected function getProviders(): array {
        return $this->providers;
    }
    // </editor-fold>

    // <editor-fold desc="API">
    // =========================================================================
    /**
     * @inheritdoc
     */
    public function getData(): array {
        $array    = array_reverse($this->getProviders());
        $callback = function (array $previous, DataProvider $current): array {
            $data = [];

            foreach ($current->getData() as $cKey => $cData) {
                $cExpected   = reset($cData);
                $cParameters = array_slice($cData, 1);

                if ($this->isExpectedFinal($cExpected) || !$previous) {
                    $data[$cKey] = array_merge([$this->getExpectedValue($cExpected)], $cParameters);
                } else {
                    foreach ($previous as $pKey => $pData) {
                        $key         = "{$cKey} / {$pKey}";
                        $pExpected   = reset($pData);
                        $pParameters = array_slice($pData, 1);
                        $data[$key]  = array_merge([$this->getExpectedValue($pExpected)], $cParameters, $pParameters);
                    }
                }
            }

            return $data;
        };

        return array_reduce($array, $callback, []);
    }

    // </editor-fold>

    // <editor-fold desc="Functions">
    // =========================================================================
    protected function isExpectedFinal(mixed $expected): bool {
        return $expected instanceof ExpectedFinal;
    }

    protected function getExpectedValue(mixed $expected): mixed {
        return $expected instanceof ExpectedValue
            ? $expected->getValue()
            : $expected;
    }
    // </editor-fold>
}
