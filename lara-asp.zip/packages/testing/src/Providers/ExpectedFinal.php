<?php declare(strict_types = 1);

namespace LastDragon_ru\LaraASP\Testing\Providers;

class ExpectedFinal extends ExpectedValue {
    // empty
}
