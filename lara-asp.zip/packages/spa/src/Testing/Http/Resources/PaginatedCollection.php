<?php declare(strict_types = 1);

namespace LastDragon_ru\LaraASP\Spa\Testing\Http\Resources;

use LastDragon_ru\LaraASP\Testing\Constraints\Json\JsonSchemaWrapper;

class PaginatedCollection extends JsonSchemaWrapper {
    // empty
}
