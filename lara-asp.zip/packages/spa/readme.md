# SPA Helpers

> This package is the part of Awesome Set of Packages for Laravel.
>
> [Read more](https://github.com/LastDragon-ru/lara-asp).


# Installation

```shell
composer require lastdragon-ru/lara-asp-spa
```
