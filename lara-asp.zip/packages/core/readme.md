# The Core

> This package is the part of Awesome Set of Packages for Laravel.
>
> [Read more](https://github.com/LastDragon-ru/lara-asp).

This package contains useful utilities and classes. Please see the [source code](./src) to find something interesting 😅


# Installation

```shell
composer require lastdragon-ru/lara-asp-core
```
