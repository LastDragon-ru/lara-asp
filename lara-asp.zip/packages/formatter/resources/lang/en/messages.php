<?php declare(strict_types = 1);

return [
    'filesize' => [
        'bytes' => 'bytes',
        'KB'    => 'KB',
        'MB'    => 'MB',
        'GB'    => 'GB',
        'TB'    => 'TB',
        'PB'    => 'PB',
    ],
];
