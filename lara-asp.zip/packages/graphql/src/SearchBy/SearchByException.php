<?php declare(strict_types = 1);

namespace LastDragon_ru\LaraASP\GraphQL\SearchBy;

use Exception;

class SearchByException extends Exception {
    // empty
}
