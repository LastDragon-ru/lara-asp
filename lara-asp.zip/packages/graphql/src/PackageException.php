<?php declare(strict_types = 1);

namespace LastDragon_ru\LaraASP\GraphQL;

use Exception;

class PackageException extends Exception {
    // empty
}
