module VagrantPlugins
  module HostManager
    VERSION = '1.8.9'
  end
end
